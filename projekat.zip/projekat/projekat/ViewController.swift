//
//  ViewController.swift
//  projekat
//
//  Created by Ivan Savovic on 9/27/17.
//  Copyright © 2017 Ivan Savovic. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    
    @IBOutlet weak var weatherImage: UIImageView!
    @IBOutlet weak var weatherImage1: UIImageView!
    @IBOutlet weak var weatherImage2: UIImageView!
    @IBOutlet weak var tempLabel: UILabel!
    @IBOutlet weak var tempLabel1: UILabel!
    @IBOutlet weak var tempLabel2: UILabel!
    @IBOutlet weak var weatherLabel: UILabel!
    @IBOutlet weak var weatherLabel1: UILabel!
    @IBOutlet weak var weatherLabel2: UILabel!
    
    
    let vreme = [
        "Clear": UIImage(named: "clear.pdf"),
        "Chancerain": UIImage(named: "chancerain.pdf"),
        "Fog": UIImage(named: "fog.pdf"),
        "Rain": UIImage(named: "rain.pdf"),
        "Snow": UIImage(named: "snow.pdf"),
        "Sleet": UIImage(named: "sleet.pdf")
    ]
    
    var weather = DataModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Za downlodovanje podataka sa neta
        weather.downloadData {
            self.updateUI()
        }
        
    }
    // Da updateuje vreme
    func updateUI() {
        
        tempLabel.text = "\(weather.temp)"
        weatherLabel.text = weather.weather
        weatherImage.image = UIImage(named: weather.weather)
        
        tempLabel1.text = "\(weather.temp)"
        weatherLabel1.text = weather.weather
        weatherImage1.image = UIImage(named: weather.weather)
        
        tempLabel2.text = "\(weather.temp)"
        weatherLabel2.text = weather.weather
        weatherImage2.image = UIImage(named: weather.weather)
    }
    
/*
     Pokusao sam i zajsta sam se potrudio da uradim aplikaciju do kraja. Nisam bio u mogucnosti jer mi fali dosta prakse. Zato se nadam da cete to uzeti u obzir prilikom provere aplikacije i dati mi sansu da odradim praksu kod vas.
    
    Hvala Vam unapred
    
    Ivan Savovic
 
 */
    
}

