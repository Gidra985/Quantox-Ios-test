//
//  DataModel.swift
//  projekat
//
//  Created by Ivan Savovic on 9/27/17.
//  Copyright © 2017 Ivan Savovic. All rights reserved.
//

import Foundation
import Alamofire

class DataModel {
    
    private var _temp: String?
    private var _weather: String?
    typealias JSONStandard = Dictionary<String, AnyObject>
    
    // Url odakle povlaci temperaturu ( key koji ste mi poslali nisam mogao da iskoristim jer non stop mi prijavljivao gresku )
    let url = URL(string: "http://api.openweathermap.org/data/2.5/weather?q=Belgrade&appid=a7bbbd5e82c675f805e7ae084f742024")!
    
    //vraca temperaturu
    var temp: String {
        return _temp ?? "0 °C"
    }
    
    var weather: String {
        return _weather ?? "Weather Invalid"
    }
    
    //komplet downloduje podatke
    func downloadData(completed: @escaping ()-> ()) {
        
        Alamofire.request(url).responseJSON(completionHandler: {
            response in
            let result = response.result
            
            if let dict = result.value as? JSONStandard, let main = dict["main"] as? JSONStandard, let temp = main["temp"] as? Double, let weatherArray = dict["weather"] as? [JSONStandard], let weather = weatherArray[0]["main"] as? String, let _ = dict["name"] as? String, let sys = dict["sys"] as? JSONStandard, let _ = sys["country"] as? String, let _ = dict["dt"] as? Double {
                
                self._temp = String(format: "%.0f °C", temp - 273.15)
                self._weather = weather
                
                }
            completed()
        })
    }
}
