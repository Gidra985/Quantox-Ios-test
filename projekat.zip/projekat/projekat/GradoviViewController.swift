//
//  GradoviViewController.swift
//  projekat
//
//  Created by Ivan Savovic on 9/27/17.
//  Copyright © 2017 Ivan Savovic. All rights reserved.
//

import UIKit

class GradoviViewController: UIViewController,UITableViewDelegate {

    var listaGradova = [String]()
        
        
        
    @IBOutlet weak var listaGradovaTable: UITableView!
    
        
        override func viewDidLoad() {
            super.viewDidLoad()
            
            if UserDefaults.standard.object(forKey: "listaGradova") != nil {
                
                listaGradova = UserDefaults.standard.object(forKey: "listaGradova") as! [String]
                
            }
            
        }
        
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            
        }
        
        
        func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            
            return listaGradova.count
            
        }
        
    private func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: IndexPath) -> UITableViewCell {
            
            let cell = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: "Cell")
            
            cell.textLabel?.text = listaGradova[indexPath.row]
            
            return cell
            
        }
        
        func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
            
            if editingStyle == UITableViewCellEditingStyle.delete {
                
                listaGradova.remove(at: indexPath.row)
                
                UserDefaults.standard.set(listaGradova, forKey: "listaGradova")
                
                listaGradovaTable.reloadData()
            }
            
            
            
        }
        
    override func viewDidAppear(_ animated: Bool) {
            
            listaGradovaTable.reloadData()
            
        }
        
        
        
}


